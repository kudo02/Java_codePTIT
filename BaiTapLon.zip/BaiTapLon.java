/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaptit.Quan_He_Giua_Cac_Class.QuanLyBaiTapNhom1;

/**
 *
 * @author Lenovo
 */
public class BaiTapLon {
    private String name;
    private int nhom;

    public BaiTapLon(String name, int nhom) {
        this.name = name;
        this.nhom = nhom;
    }
    
    public int getNhom() {
        return nhom;
    }

    public String getName() {
        return name;
    }
    
}

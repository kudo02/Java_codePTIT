/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaptit.Quan_He_Giua_Cac_Class.QuanLyBaiTapNhom1;

/**
 *
 * @author Lenovo
 */
public class SinhVien {
    private String ma, name, sdt;
    private int nhom;

    public SinhVien(String ma, String name, String sdt, int nhom) {
        this.ma = ma;
        this.name = name;
        this.sdt = sdt;
        this.nhom = nhom;
    }

    @Override
    public String toString() {
        return this.ma + " " + this.name + " " + this.sdt;
    }

    public int getNhom() {
        return nhom;
    }
    
}
